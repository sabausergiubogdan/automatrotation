from stateMachineV2 import State, HSM

class Combat(HSM):
    transitions = {} 
